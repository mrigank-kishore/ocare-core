package com.care.service.cbdb.core.interact;

public class CBDBInteract {
	
	
	public static void main(String[] args) {
		CBDBService service = new CBDBService();
		service.getBucket();

	}

}
