package com.care.service.cbdb.core.sdo;

public class GenericResponseBean {

}
